import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import App from './Components/app';
ReactDOM.render(<App />, document.getElementById('app'));
